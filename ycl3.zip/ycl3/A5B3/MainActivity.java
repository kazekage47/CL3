package com.example.naman.calapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Context;

public class MainActivity extends AppCompatActivity {

    private Button add;
    private Button file;
    private Button tan;
    private Button save;
    private Button recall;
    private EditText num1;
    private EditText num2;
    private TextView res;

    String st;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        add = (Button)findViewById(R.id.add);
        tan = (Button)findViewById(R.id.tan);

        num1 = (EditText)findViewById(R.id.editText);
        num2 = (EditText)findViewById(R.id.editText2);

        res = (TextView)findViewById(R.id.textView);

        save = (Button)findViewById(R.id.save);
        recall = (Button)findViewById(R.id.Recall);
        file = (Button)findViewById(R.id.file);


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = Double.parseDouble(num1.getText().toString());
                double n2 = Double.parseDouble(num2.getText().toString());
                num1.setText("");
                num2.setText("");
                n1 = n1+n2;
                res.setText(String.valueOf(n1));
            }
        });

        tan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n1 = Double.parseDouble(num1.getText().toString());
                res.setText(String.valueOf(Math.tan(n1)));
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                st = res.getText().toString();
            }
        });

        recall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num1.setText(st);
            }
        });

        file.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });

    }
}
