import unittest

def search(l,r,a,num) :
	if(l>r) :
		return -1
	mid = int((l+r)/2)
	if a[mid] == num :
		return mid
	if a[mid] > num :
		return search(l,mid-1,a,num)
	return search(mid+1,r,a,num)

def func(a, num):
	a = list(map(int,a.split()))
	a.sort()
	num = int(num)
	return search(0,len(a)-1,a,num)