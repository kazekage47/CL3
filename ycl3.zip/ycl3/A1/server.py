from binary import *
from flask import Flask,request, render_template

app= Flask(__name__)

@app.route('/')
def mainpage():
	return render_template('index.html', product=None)

@app.route('/yash', methods=['POST', 'GET'])
def mul():
	z=func(request.form['num1'],request.form['num2'])
	return render_template('index.html', product=z)
app.run()
